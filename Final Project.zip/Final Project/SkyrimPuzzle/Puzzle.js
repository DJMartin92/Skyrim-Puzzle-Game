let currentRoom = "prologue";

const rooms = {
    prologue: {
        description: "You awaken in the Forgotten Barrow after too many drinks at the Drunken Huntsman.\n\nType 'stand' to gather your bearings.",
        options: {
            stand: "barrow1"
        }
    },

    barrow1: {
        description: "You hear distant growls of draugr lurking in the shadows. \n\nDo you choose to 'sneak' or 'fight'?",
        options: {
            sneak: "barrow2",
            fight: "barrow2"
        }
    },

    barrow2: {
        description: "You take a step deeper into the cold and damp crypt. There is dust and bones scattered all across the floor. Amongst all of the dust and bones, you stumble upon 2 pillars with 2 choices, an animal on each side. You take a look around thinking these have to mean something. You look north and see there is a gate that you cannot pass, but there is two statues of animals above the gate. There is a bear on the left and a hawk on the right. You realize these statues are also carved onto the pillars.\n\nYou decide you need to spin the pillars so that it will show the animal in the correct order. You start with the left pillar, does 'bear' or 'hawk' come first?",
        options: {
            bear: "barrow4",
            hawk: "barrow3"
        }
    },

    barrow3: {
      description: "You chose wrong! You were just shot by a poisonous arrow!\n\nLuckily that did no damage to you. Now you have to decide whether to turn the pillar 'right' or 'left.",
      options: {
        right: "barrow5",
        left: "barrow5"
      }
    },

    barrow4: {
      description: "Don't get cocky, you got one right. Now you need to choose 'bear' or 'hawk on the next pillar.",
      options: {
        bear: "barrow3",
        hawk: "barrow8"
      }
    },

    barrow5: {
      description: "You realize, it doesn't matter which way you turn the pillar! So you can choose 'left' or 'right'.",
      options: {
        left: "barrow8",
        right: "barrow8"
      }
    },

    barrow8: {
      description: "You hear the gate slowly open loudly, crashing into the wall above it. Now you have two paths ahead,\n\none to the 'north' that leads to a doorway, or 'east' that leads to a crumbled pile of rubble you can step over. Which way will you choose?",
      options: {
        north: "barrow10",
        east: "barrow10"
      }
    },

    barrow10: {
        description: "You take a step through the cob web ridden door frame into a huge cavern that looks like it may have been a great hall at one point. There are caskets laying against the wall and there is a 30 foot long stone feast table with 20 stone chairs surrounding it. About 10 feet further, you see stairs leading up to a massive iron casket. You take a one step into the room and hear the casket start cracking like it is opening.\n\nType 'casket' to search the caskets on the wall for a way out, or 'search' to investigate the creaking iron casket.",
        options: {
            casket: "casketFight",
            search: "casketWin"
          }
        },
      
        casketFight: {
          description: "You try to find a way out, but the iron casket bursts open. A powerful draugr attacks you. You barely win the fight, but you're alive. You scramble over to the pile of bones and dust to check out the loot.\n\nThere is a full iron armor set here! Do you 'loot' the set or 'leave' the set for the next adventure who wanders in here?",
          options: {
            loot: "dragonsreach1",
            leave: "dragonsreach1"
          }
        },
      
        casketWin: {
          description: "You sneak to the casket and attack just as it opens. You slay the elite draugr and loot a full set of iron armor. Nice!\n\nAs you get ready to leave to go back to Whiterun, you decide to check the pile of bones for loot, do you 'collect' the armor or 'leave' it for the next adventurer?",
          options: {
            collect: "dragonsreach1",
            leave:  "dragonsreach1"
          }
        },

      dragonsreach1: {
        description: "Who are you kidding, you would never leave that set of armor you almost died for in that barrow! As you make your return to Whiterun in your full set of new to you iron armor feeling untouchable, you decide to sell off some of the loot your retrieved from the barrow and head to the cloud district for new quests. As you enter you hear a guard ask in a rather smug voice awww did someone steal your sweetroll?\n\nThis leaves you with a choice, do you 'attack' and fus ro dah this chump into next week, or do you keep 'quiet' and look for quests?",
        options: {
          attack: "dragonsreach2",
          quiet: "dragonsreach3"
        }
      },

      dragonsreach2: {
        description: "Welp, I don't know what you expected, you now have the entirety of the White run guard chasing you through Dragon's Reach. As you make your way through the palace, mowing down every guard you see, you find a spot to sneak and hide in the corner. You are now safe. When you stand back up, you hear, Wait I know you!\n\nYou can either 'bribe' the guard or 'submit' and go to jail. What will you choose?",
        options: {
          bribe: "whiterun1",
          submit: "whiterun1"
        }
      },

      dragonsreach3: {
        description: "You have chosen peace. As you walk away questioning why you didn't molliwhop that man, you walk into the wizard's office to see if he has any quests. Of course, he does not and asks you why you're still standing there and not on your way to Bleak Falls Barrow.\n\nYou decide to see if there is anything else to 'loot' or 'talk' to other NPCs before making your way back out to Whiterun.",
        options: {
          loot: "whiterun1",
          talk: "whiterun1"
        }
      },

      whiterun1:{
        description: "You take a step out of Dragon's Reach and take a long breath of fresh air, you are free to do as you please. That is, until you see Nazeem heading towards you on his way to suck up to the Jarl. He stops in front of you and asks, Do you get to the cloud district often? Oh what am I saying, of course you don't. Stricken with a blind rage, you decide this dude is done.\n\nDo you 'shout' him apart with a vigorous fus ro dah? Or do you challenge him to a 'duel' of fisticuffs?",
        options: {
          shout: "whiterun2",
          duel: "whiterun3"
        }

      },

      whiterun2: {
        description: "You chose violence. You melted Nazeem right before your eyes. There is nothing left of the man except his robe, shoes, 5 sweet rolls, and a wierd golden claw. You decide to sell the clothing and keep the claw and sweet rolls, who doesn't want a sweet roll? Both of these items may come in handy later on. After collecting your loot, you hear the sound of guards running towards you from inside the keep. Making a run for the gate to escape Whiterun you leave a trail of sweet rolls hoping to distract the guards.\n\nAmazed that your tactic worked, you have two choices, 'hide' in an alley and hope they go back inside soon, or 'run' to the gate.",
        options: {
          hide: "whiterungate1",
          run: "whiterungate1"
        }
      },

      whiterun3: {
        description: "You decide you have more honor than just ripping him apart and want to give him a fair chance. Not what I would have chosen, but hey, this is your adventure. You challenge Nazeem to a duel. He stops and stutters....a...what?...you want to what?.. After more stumbling over his words, he fearfully accepts and throws the first punch. You of course, don't hold back at all and you beat him to a pulp. As he is laying there dead, you start looking through his pockets, why not get loot? You find 5 sweet rolls and a weird golden dragon claw, maybe these will help later on?\n\nYou hear the sound of guards running towards you from the keep. Making a run for the gate to escape Whiterun you leave a trail of sweet rolls hoping to distract the guards.\n\nAmazed that your tactic worked, you have two choices, 'hide' in an alley and hope they go back inside soon, or 'run' to the gate.",
        options: {
          hide: "whiterungate1",
          run: "whiterungate1"
        }
      },

      whiterungate1: {
        description: "Well, it looks like you escaped the guards, time to blow this pop stand before they find you. As you walk up to the gate, you notice its sealed. You push against it and try to wedge it open, but nothing, it is still sealed shut. As you start to ponder your life decisions and go through your mod list, wondering which mod broke your Whiterun gate, you notice a weird cobble stone that looks out of place. For some reason, you cannot fight the urge to stand on it. As you step onto the weird cobblestone, you watch in disbelief as the gate slowly creaks open. You jump up and down a few times and realize this cobblestone is what is opening the gate. Immediately, you start looking around for something to plop down on this cobblestone to keep the gate open. You see rocks, logs and other various items, but nothing quite big enough to get the cobblestone button to open the gate. After checking nearby houses, you go into the guardhouse. You figure all the guards were chasing you by the keep, theres no way they've made it back yet. Upon entering the room, you see a dead guard on a cot, absolutely filled with arrows. You make a joke to yourself about him taking an arrow everywhere except his knees and start dragging his corpse to the button. Once at the button, the corpse is plopped down and the gate is open!\n\nExpecting to be outside of Whiterun, you are sorely mistaken. You are in a long tunnel with drawing of dragons all over the walls! You can either 'stay' a minute and observe the drawings, or 'move' on towards the door.",
        options: {
          stay: "dcdoor1",
          move: "dcdoor1"
        }
      },

      dcdoor1: {
        description: "Walking down the path, fully enamored by the drawings, you make your way to the door. It is a massive stone door that looks like it spins. In the center, you see a circle shaped stone. You see that it has holes in it that may match the dragon claw that Nazeem dropped. You quickly pull the dragon claw out and examine it. You see that it fits the holes and notice that it has 2 circles with animals in them. You think, aw crap not this again. The top animal is a bear and the bottom animal is a hawk. You examine the door again after placing the claw in the door, and notice the two stone rings that move around the middle circle have the same animals on it. You think to yourself this should be easy knowing what I know from last time. You start with the top ring.\n\nAre you going to pick 'bear' or 'hawk'?",
        options: {
          bear: "dcdoor3",
          hawk: "dcdoor2"
        }
      },

      dcdoor2: {
        description: "Welp, you didn't learn from the first time, now you get to pull poison arrows out of your body again. This time they did a bit of damage, but you quickly regen them. Now would you like to try that again?\n\n'bear' or 'hawk'?",
        options: {
          bear: "dcdoor3",
          hawk: "dcdoor2"
        }
      },

      dcdoor3: {
        description: "Hey, you chose correct! No arrows you exclaim as you eye up the holes in the wall where the arrows are shot from. Let's move on to the second ring.\n\n'bear' or 'hawk'?",
        options: {
          bear: "dcdoor2",
          hawk: "dcdoor4"
        }
      },

      dcdoor4: {
        description: "you hear a click and are now able to turn the dragon claw key. While doing so, the massive stone door creaks and you feel the ground below you shake. As you step through the doorway, you see a chest to your right. You think to yourself, its about time I find some loot in here! As you open the chest you see two sets of weapons, two orcish daggers, an elven bow, and 100 elven arrows.\n\nWhich will you take? The 'daggers' or the 'bow' and arrows?",
        options: {
          daggers: "dragonsanctum1",
          bow: "dragonsanctum1"
        }
      },

      dragonsanctum1: {
        description: "Again! Who are you kidding, you greedily scooped all 3 weapons! Little did you know all 3 will come in handy with what comes next. As you walk into the huge canyon, you hear loud shrieks and roars. You ready your axe and shield. There's an elder dragon coming your way!\n\nDo you try to stealth with your 'daggers'? Or do you take pot shots at it with your 'bow' until it lands?",
        options: {
          daggers: "ds3",
          bow: "ds4"
        }
      },

      ds3: {
        description: "You decide to crouch and wait for it to land, hoping you can get a sneak attack in. You sneak over to the shadows and start waiting. After about 5 minutes of watching the dragon fly around, light stuff on fire, and sing the song of its people, it finally lands. It continues walking around a bit like it knows you're still there. Finally it lays down and curls up for a nap, all that ruckus really tuckered it out. You slowly sneak over and move towards the dragons face. You are now looking directly at its closed right eye. You can see the steam flowing out of its nostrils as it exhales. Its now or never you think to yourself! As you make a move to stab it in the eye, it opens in front of you. You are now making eye contact with the elder dragon! You both stare at each for a few seconds before it raises its head. You quickly jump on the dragon's head and start vigorously stabbing it. The dragon takes off into the air with you on its head, frantically struggling and breathing fire in every direction. After about 20 or 30 stabs, you make your way closer to its eyes and snout, continuing to stab away. You finally muster up the strength to do a double dagger attack into its right eye. The dragon shrieks in agony as it start plummeting back down the canyon. As you get closer to the ground, you get ready to time your jump to get off this sinking ship. As it nosedives into the ground, you hastily jump off and take a load of fall damage. Good thing you have your sweet rolls! You quickly eat one and start regenerating your heatlh.\n\nDo you want to 'look' at the dragon or 'loot' the dragon?",
        options: {
          look: "ds5",
          loot: "ds5"
        }
      },
      
      ds4: {
        description: "Of course you took the stealth archer approach. You sneak over into the shadows and wait for the dragon to land. After about 5 minutes of watching the dragon fly around, light stuff on fire, and sing the song of its people, it finally lands. It continues walking around a bit like it knows you're still there. Finally it lays down and curls up for a nap, all that ruckus really tuckered it out. You draw your bow and take aim. You think, huh, this thing doesn't look all that tough now. You release the arrow and watch it clink off of the rock the dragon was resting on. Good job stealth archer, fantastic work. The dragon opens one eye, and you can tell it's angry. It jumps up and takes to the sky, soaring and filling the sky with fire. You decide to pop out of your hidey hole and start the barrage of arrows. After hitting it with a couple of arrows, you see the dragon start to descent and it lands. It looks like you have pierced the dragon's left wing. With the dragon grounded, you have to start running and dodging bites and flames. You land another shot on its face. The dragon is beginning to look like a pin cushion. You ready 3 arrows in your bow, and wait for a good shot. The dragon in enraged at this point and lifts its head to roar and fill the sky with more fire. As it does that, you release all three arrows aimed at its neck. You connect with all 3 and it finally collapses.\n\nDo you want to go 'look' at the dragon or 'loot' the dragon?",
        options: {
          look: "ds5",
          loot: "ds5"
        }
      },

      ds5: {
        description: "The dragon lies defeated. You approach the massive beast and loot its scaly corpse. You think to yourself, oh man, i'm going to make a fortune off of this dragot! As you start looting you find 3 dragon bones, 3 dragon scales, 200 gold, and a perfectly preserved ebony battle axe. You roll your eyes and let out a sigh of disappointment. All that work for 3 bones and 3 scales?! I can barely make anything from that! At least you got a sweet ebony battle axe, and you still have a sweet roll! As you make your way out of the sanctum, you see a familiar home in the distance — Breezehome. You step inside, place your loot in the chest, devour your last sweet roll and collapse into bed.\n\nYou've survived. For now.\n\nTHE END.",
      },

    };

function display(text) {
    document.getElementById("game-output").innerText = text;
  }
  
  function processCommand() {
    const input = document.getElementById("command").value.toLowerCase().trim();
    const room = rooms[currentRoom];
  
    if (room.options[input]) {
      currentRoom = room.options[input];
      display(rooms[currentRoom].description);
    } else {
      display("Invalid command. Try something else.");
    }
  
    document.getElementById("command").value = "";
  }
  
  // Start game
  window.onload = function () {
    display(rooms[currentRoom].description);
  };